#!/usr/bin/env python3
import json
import sys
from pathlib import Path

AGENTOPS_DIR = Path(__file__).parent
GATE_LOG_PATH = AGENTOPS_DIR / "gate-log.jsonl"
FAIL_STREAK_THRESHOLD = 3


def load_records() -> list[dict]:
    if not GATE_LOG_PATH.exists():
        return []
    records = []
    for line_number, line in enumerate(GATE_LOG_PATH.read_text().splitlines(), start=1):
        line = line.strip()
        if not line:
            continue
        try:
            records.append(json.loads(line))
        except json.JSONDecodeError as error:
            print(
                f"[WARN] Skipping malformed line {line_number} in {GATE_LOG_PATH}: {error}",
                file=sys.stderr,
            )
    return records


def consecutive_reject_streaks(records: list[dict]) -> dict[str, int]:
    streaks: dict[str, int] = {}
    current: dict[str, int] = {}
    for record in records:
        task = record["task"]
        if record["verdict"] == "REJECT":
            current[task] = current.get(task, 0) + 1
        else:
            current[task] = 0
        streaks[task] = max(streaks.get(task, 0), current[task])
    return streaks


def find_alerts(threshold: int = FAIL_STREAK_THRESHOLD) -> list[dict]:
    records = load_records()
    streaks = consecutive_reject_streaks(records)
    return [
        {"task": task, "consecutive_rejects": streak}
        for task, streak in streaks.items()
        if streak >= threshold
    ]


def main() -> bool:
    alerts = find_alerts()
    if not alerts:
        print("[OK] No task has >= 3 consecutive REJECTs")
        return True
    for alert in alerts:
        print(
            f"[ALERT] Task '{alert['task']}' has {alert['consecutive_rejects']} "
            "consecutive REJECTs — needs human attention"
        )
    return False


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
