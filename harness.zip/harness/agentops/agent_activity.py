import glob
import json
from collections import defaultdict
from pathlib import Path

from token_usage import session_dir


def _iter_tool_use_blocks(directory: Path):
    for file_path in glob.glob(str(directory / "*.jsonl")):
        try:
            with open(file_path, encoding="utf-8") as handle:
                for line in handle:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        record = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if record.get("type") != "assistant":
                        continue
                    message = record.get("message")
                    if not isinstance(message, dict):
                        continue
                    for block in message.get("content") or []:
                        if isinstance(block, dict) and "name" in block:
                            yield block
        except OSError:
            continue


def get_agent_dispatch_stats() -> dict:
    directory = session_dir()
    if not directory.exists():
        return {"total": 0, "by_subagent_type": {}}
    counts: dict[str, int] = defaultdict(int)
    for block in _iter_tool_use_blocks(directory):
        if block.get("name") == "Agent":
            subagent_type = block.get("input", {}).get("subagent_type", "(unspecified)")
            counts[subagent_type] += 1
    return {
        "total": sum(counts.values()),
        "by_subagent_type": dict(sorted(counts.items(), key=lambda kv: -kv[1])),
    }


def get_context_doc_read_count() -> dict:
    directory = session_dir()
    if not directory.exists():
        return {"claude_md": 0, "docs_architecture": 0}
    claude_md = 0
    docs_architecture = 0
    for block in _iter_tool_use_blocks(directory):
        if block.get("name") != "Read":
            continue
        path = block.get("input", {}).get("file_path", "")
        if path.endswith("CLAUDE.md"):
            claude_md += 1
        elif "docs/architecture/" in path:
            docs_architecture += 1
    return {"claude_md": claude_md, "docs_architecture": docs_architecture}
