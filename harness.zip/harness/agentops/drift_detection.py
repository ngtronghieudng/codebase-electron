#!/usr/bin/env python3
import json
import sys
from pathlib import Path

AGENTOPS_DIR = Path(__file__).parent
GATE_LOG_PATH = AGENTOPS_DIR / "gate-log.jsonl"

MIN_RECORDS_FOR_PASS_RATE_DRIFT = 10
MIN_DAYS_FOR_TOKEN_DRIFT = 14
PASS_RATE_DROP_THRESHOLD_PP = 20.0
TOKEN_USAGE_SPIKE_RATIO = 1.5


def load_gate_records() -> list[dict]:
    if not GATE_LOG_PATH.exists():
        return []
    records = []
    for line in GATE_LOG_PATH.read_text().splitlines():
        line = line.strip()
        if line:
            records.append(json.loads(line))
    return records


def pass_rate(records: list[dict]) -> float:
    if not records:
        return 0.0
    passes = sum(1 for r in records if r["verdict"] == "PASS")
    return 100 * passes / len(records)


def check_pass_rate_drift(records: list[dict]) -> dict:
    if len(records) < MIN_RECORDS_FOR_PASS_RATE_DRIFT:
        return {
            "signal": "pass_rate",
            "drift": False,
            "reason": f"insufficient data — need >= {MIN_RECORDS_FOR_PASS_RATE_DRIFT} gate-log records, have {len(records)}",
        }
    midpoint = len(records) // 2
    baseline_rate = pass_rate(records[:midpoint])
    recent_rate = pass_rate(records[midpoint:])
    drop = baseline_rate - recent_rate
    return {
        "signal": "pass_rate",
        "drift": drop >= PASS_RATE_DROP_THRESHOLD_PP,
        "baseline_pass_rate": round(baseline_rate, 1),
        "recent_pass_rate": round(recent_rate, 1),
        "reason": f"pass rate dropped {drop:.1f}pp (threshold {PASS_RATE_DROP_THRESHOLD_PP}pp)",
    }


def check_token_usage_drift(daily_stats: list[dict]) -> dict:
    if len(daily_stats) < MIN_DAYS_FOR_TOKEN_DRIFT:
        return {
            "signal": "token_usage",
            "drift": False,
            "reason": f"insufficient data — need >= {MIN_DAYS_FOR_TOKEN_DRIFT} days, have {len(daily_stats)}",
        }
    midpoint = len(daily_stats) // 2
    baseline = daily_stats[:midpoint]
    recent = daily_stats[midpoint:]

    def total_tokens(days: list[dict]) -> float:
        return sum(d["input_tokens"] + d["output_tokens"] for d in days) / max(
            len(days), 1
        )

    baseline_avg = total_tokens(baseline)
    recent_avg = total_tokens(recent)
    ratio = recent_avg / baseline_avg if baseline_avg else 1.0
    return {
        "signal": "token_usage",
        "drift": ratio >= TOKEN_USAGE_SPIKE_RATIO,
        "baseline_avg_tokens_per_day": round(baseline_avg),
        "recent_avg_tokens_per_day": round(recent_avg),
        "reason": f"recent/baseline token ratio {ratio:.2f}x (threshold {TOKEN_USAGE_SPIKE_RATIO}x)",
    }


def detect_drift() -> dict:
    sys.path.insert(0, str(AGENTOPS_DIR))
    from token_usage import get_token_stats

    gate_records = load_gate_records()
    token_stats = get_token_stats()
    daily_stats = token_stats.get("daily", [])

    signals = [
        check_pass_rate_drift(gate_records),
        check_token_usage_drift(daily_stats),
    ]
    return {
        "drift_detected": any(s["drift"] for s in signals),
        "signals": signals,
    }


def main() -> bool:
    result = detect_drift()
    for signal in result["signals"]:
        marker = "[DRIFT]" if signal["drift"] else "[OK]"
        print(f"{marker} {signal['signal']}: {signal['reason']}")
    return not result["drift_detected"]


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
