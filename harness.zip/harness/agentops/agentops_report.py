#!/usr/bin/env python3
import json
import sys
from collections import defaultdict
from pathlib import Path

LOG_PATH = Path("harness/agentops/gate-log.jsonl")


def load_records():
    if not LOG_PATH.exists():
        return []
    records = []
    with LOG_PATH.open(encoding="utf-8") as log_file:
        for line_number, line in enumerate(log_file, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError as error:
                print(
                    f"[WARN] Skipping malformed line {line_number} in {LOG_PATH}: {error}",
                    file=sys.stderr,
                )
    return records


def main():
    records = load_records()
    if not records:
        print("[INFO] No gate-log records yet — run uam-auto-implement at least once.")
        return True

    total = len(records)
    passes = [record for record in records if record["verdict"] == "PASS"]
    rejects = [record for record in records if record["verdict"] == "REJECT"]

    cycles_by_task = defaultdict(list)
    for record in records:
        cycles_by_task[record["task"]].append(record["cycle"])

    first_pass_tasks = [
        task
        for task, cycles in cycles_by_task.items()
        if max(cycles) == 1
        and any(r["task"] == task and r["verdict"] == "PASS" for r in records)
    ]

    print("=" * 60)
    print("AgentOps Gate Reliability Report")
    print("=" * 60)
    print(f"Total gate runs logged: {total}")
    print(f"PASS: {len(passes)} ({100 * len(passes) / total:.1f}%)")
    print(f"REJECT: {len(rejects)} ({100 * len(rejects) / total:.1f}%)")
    print(f"Distinct tasks: {len(cycles_by_task)}")
    print(f"Tasks that passed on cycle 1 (no retry needed): {len(first_pass_tasks)}")

    coverage_values = [
        record["coverage_pct"]
        for record in records
        if record.get("coverage_pct") is not None
    ]
    if coverage_values:
        print(f"Latest coverage seen: {coverage_values[-1]:.2f}%")
        print(f"Min coverage seen: {min(coverage_values):.2f}%")

    print("-" * 60)
    print("Last 5 runs:")
    for record in records[-5:]:
        print(
            f"  {record['timestamp']} | {record['verdict']:6} | cycle {record['cycle']} | "
            f"{record['task']}"
        )
    print("=" * 60)
    return True


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
