#!/usr/bin/env python3
import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

LOG_PATH = Path(__file__).parent / "escalations.jsonl"


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--task")
    parser.add_argument("--cycle", type=int)
    parser.add_argument("--findings")
    parser.add_argument(
        "--find",
        help="Look up past escalations matching these task keywords instead of logging a new one",
    )
    args = parser.parse_args()
    if args.find is None and (
        args.task is None or args.cycle is None or args.findings is None
    ):
        parser.error("--task/--cycle/--findings are required unless --find is used")
    return args


def append_escalation(task: str, cycle: int, findings: str) -> dict:
    record = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "task": task,
        "cycle": cycle,
        "findings": findings,
    }
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with LOG_PATH.open("a") as log_file:
        log_file.write(json.dumps(record) + "\n")
    return record


def find_relevant_escalations(task_keywords: str) -> list[dict]:
    if not LOG_PATH.exists():
        return []
    keywords = {word.lower() for word in task_keywords.split() if len(word) > 3}
    matches = []
    for line in LOG_PATH.read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        record = json.loads(line)
        record_words = set(record["task"].lower().split())
        if keywords & record_words:
            matches.append(record)
    return matches


def main() -> bool:
    args = parse_args()
    if args.find is not None:
        matches = find_relevant_escalations(args.find)
        if not matches:
            print(f"[OK] No past escalations match '{args.find}'")
        for match in matches:
            print(
                f"[MATCH] {match['timestamp']} — {match['task']} (cycle {match['cycle']})"
            )
            print(f"        {match['findings']}")
        return True

    record = append_escalation(args.task, args.cycle, args.findings)
    print(
        f"[SUCCESS] Logged escalation for '{record['task']}' (cycle {record['cycle']})"
    )
    return True


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
