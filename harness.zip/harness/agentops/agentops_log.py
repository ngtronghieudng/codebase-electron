#!/usr/bin/env python3
import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

AGENTOPS_DIR = Path(__file__).parent
LOG_PATH = AGENTOPS_DIR / "gate-log.jsonl"

sys.path.insert(0, str(AGENTOPS_DIR))
from redact import redact
from token_usage import git_user


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--task", required=True)
    parser.add_argument("--verdict", required=True, choices=["PASS", "REJECT"])
    parser.add_argument("--cycle", required=True, type=int)
    parser.add_argument("--check-all", required=True, choices=["pass", "fail"])
    parser.add_argument("--test-cov", required=True, choices=["pass", "fail"])
    parser.add_argument("--coverage-pct", type=float, default=None)
    return parser.parse_args()


def read_last_record() -> dict | None:
    if not LOG_PATH.exists():
        return None
    lines = [line for line in LOG_PATH.read_text().splitlines() if line.strip()]
    while lines:
        try:
            return json.loads(lines[-1])
        except json.JSONDecodeError as error:
            print(
                f"[WARN] Skipping malformed last line in {LOG_PATH}: {error}",
                file=sys.stderr,
            )
            lines.pop()
    return None


def is_duplicate(candidate: dict, last: dict | None) -> bool:
    if last is None:
        return False
    fields = ["task", "verdict", "cycle", "check_all", "test_cov", "coverage_pct"]
    if any(candidate[field] != last.get(field) for field in fields):
        return False
    candidate_time = datetime.fromisoformat(candidate["timestamp"])
    last_time = datetime.fromisoformat(last["timestamp"])
    return (candidate_time - last_time).total_seconds() < 5


def main():
    args = parse_args()
    record = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "git_user": git_user(),
        "task": redact(args.task),
        "verdict": args.verdict,
        "cycle": args.cycle,
        "check_all": args.check_all,
        "test_cov": args.test_cov,
        "coverage_pct": args.coverage_pct,
    }
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)

    if is_duplicate(record, read_last_record()):
        print(
            f"[SKIP] Duplicate {args.verdict} for '{args.task}' (cycle {args.cycle}) "
            "within 5s of the last identical record — idempotency guard suppressed the write"
        )
        return True

    with LOG_PATH.open("a") as log_file:
        log_file.write(json.dumps(record) + "\n")
    print(f"[SUCCESS] Logged {args.verdict} for '{args.task}' (cycle {args.cycle})")

    if args.verdict == "REJECT":
        sys.path.insert(0, str(AGENTOPS_DIR))
        from alerting import find_alerts

        for alert in find_alerts():
            if alert["task"] == redact(args.task):
                print(
                    f"[ALERT] Task '{args.task}' has {alert['consecutive_rejects']} "
                    "consecutive REJECTs — needs human attention"
                )
    return True


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
