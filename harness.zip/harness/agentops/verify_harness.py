#!/usr/bin/env python3
import glob
import json
import re
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
AGENTOPS_DIR = Path(__file__).parent


def read(relative_path: str) -> str:
    path = REPO_ROOT / relative_path
    return path.read_text() if path.exists() else ""


def exists(relative_path: str) -> bool:
    return (REPO_ROOT / relative_path).exists()


def run_hook(command: str) -> int:
    return run_hook_full(command)[0]


def run_hook_full(command: str) -> tuple[int, str]:
    payload = json.dumps({"tool_name": "Bash", "tool_input": {"command": command}})
    result = subprocess.run(
        ["node", str(REPO_ROOT / "harness" / "security" / "guard-dangerous-cmd.js")],
        input=payload,
        capture_output=True,
        text=True,
        timeout=10,
    )
    return result.returncode, result.stdout


def run_edit_hook(tool_name: str, file_path: str) -> tuple[int, str]:
    payload = json.dumps({"tool_name": tool_name, "tool_input": {"file_path": file_path}})
    result = subprocess.run(
        ["node", str(REPO_ROOT / "harness" / "security" / "guard-config-edit.js")],
        input=payload,
        capture_output=True,
        text=True,
        timeout=10,
    )
    return result.returncode, result.stdout


def run_env_hook(tool_name: str, tool_input: dict) -> tuple[int, str]:
    payload = json.dumps({"tool_name": tool_name, "tool_input": tool_input})
    result = subprocess.run(
        ["node", str(REPO_ROOT / "harness" / "security" / "guard-env-read.js")],
        input=payload,
        capture_output=True,
        text=True,
        timeout=10,
    )
    return result.returncode, result.stdout


def check_h1_context_files() -> tuple[str, str]:
    ok = exists("CLAUDE.md") and exists("harness/context/memory-hygiene.md")
    return (
        "pass" if ok else "fail",
        "CLAUDE.md + harness/context/memory-hygiene.md present",
    )


def check_h1_context_pointer_table() -> tuple[str, str]:
    text = read("CLAUDE.md")
    ok = bool(re.search(r"\|\s*File\s*\|\s*Topic\s*\|", text))
    return (
        "pass" if ok else "fail",
        "CLAUDE.md has a docs pointer table, not a monolithic doc",
    )


def check_h1_stale_cleanup() -> tuple[str, str]:
    text = read("harness/context/memory-hygiene.md")
    ok = "Prune when" in text
    return (
        "pass" if ok else "fail",
        "memory-hygiene.md defines explicit prune conditions",
    )


def check_h1_context_handoff_no_rescan() -> tuple[str, str]:
    text = read(".claude/skills/uam-auto-implement/SKILL.md")
    ok = (
        "IS the full context handoff" in text
        and "always pass the complete current context" in text
    )
    return (
        "pass" if ok else "fail",
        "uam-auto-implement.md passes each step's full artifact forward so the next agent never re-scans the repo from scratch",
    )


def check_h1_domain_knowledge_cached_once() -> tuple[str, str]:
    ok = exists("docs/architecture") and "docs/architecture" in read("CLAUDE.md")
    return (
        "pass" if ok else "fail",
        "docs/architecture/ + CLAUDE.md pointer give agents a single cached nav reference instead of re-deriving structure each session",
    )


def check_h2_tool_schema() -> tuple[str, str]:
    agent_files = glob.glob(str(REPO_ROOT / ".claude" / "agents" / "*.md"))
    missing = [f for f in agent_files if "tools:" not in Path(f).read_text()]
    ok = bool(agent_files) and not missing
    return (
        "pass" if ok else "fail",
        f"{len(agent_files)} orchestrator agent files, {len(missing)} missing tools: scoping (docs/adr/01-agents-tools-scoping-not-skills.md)",
    )


def check_h2_tool_registry() -> tuple[str, str]:
    text = read(".claude/settings.json")
    try:
        data = json.loads(text) if text else {}
    except json.JSONDecodeError:
        data = {}
    allow_list = data.get("permissions", {}).get("allow", [])
    ok = len(allow_list) > 0
    return (
        "pass" if ok else "fail",
        f"{len(allow_list)} explicit permission entries in settings.json",
    )


def check_h2_rate_limit_tool() -> tuple[str, str]:
    try:
        result = subprocess.run(
            ["rtk", "--version"], capture_output=True, text=True, timeout=5
        )
        ok = result.returncode == 0
        return ("pass" if ok else "fail", result.stdout.strip() or "rtk installed")
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return (
            "manual",
            "rtk not found on PATH — per-command rate/efficiency layer unavailable",
        )


def check_h2_idempotency_key() -> tuple[str, str]:
    registry_ok = "**Idempotency:**" in read("harness/governance/risk-registry.md")
    gate_log_ok = "is_duplicate" in read("harness/agentops/agentops_log.py")
    ok = registry_ok and gate_log_ok
    return (
        "pass" if ok else "fail",
        "Tier 0 push commands documented as safe-to-re-run (risk-registry.md) + "
        "agentops_log.py dedupes identical gate-log writes within 5s (is_duplicate)",
    )


def check_h2_audit_log_per_tool_call() -> tuple[str, str]:
    text = read("harness/security/guard-dangerous-cmd.js")
    ok = "logAudit" in text and "tool-call-audit.jsonl" in text
    return (
        "pass" if ok else "fail",
        "guard-dangerous-cmd.js logs every Bash tool call (allowed or blocked) to "
        "harness/security/tool-call-audit.jsonl, not just blocks",
    )


def check_h3_test_suite() -> tuple[str, str]:
    test_files = glob.glob(
        str(REPO_ROOT / "tests" / "**" / "*.test.ts"), recursive=True
    ) + glob.glob(str(REPO_ROOT / "tests" / "**" / "*.test.tsx"), recursive=True)
    ok = len(test_files) > 100
    return ("pass" if ok else "fail", f"{len(test_files)} test files under tests/")


def check_h3_gate_stops_on_reject() -> tuple[str, str]:
    text = read(".claude/skills/uam-auto-implement/SKILL.md")
    ok = "cycle count == 3" in text and "human decision" in text
    return ("pass" if ok else "fail", "uam-auto-implement.md defines REJECT → escalate path")


def check_h3_auto_retry_capped() -> tuple[str, str]:
    text = read(".claude/skills/uam-auto-implement/SKILL.md")
    match = re.search(r"cycle count == (\d+)", text)
    ok = bool(match)
    return (
        "pass" if ok else "fail",
        f"retry cap found: cycle count == {match.group(1)}"
        if match
        else "no cap found",
    )


def check_h3_regression_in_ci() -> tuple[str, str]:
    text = read(".gitlab-ci.yml")
    ok = "pnpm check-all" in text and "pnpm test:coverage" in text
    if ok:
        return ("pass", "quality-and-tests CI job runs pnpm check-all + pnpm test:coverage")
    if text:
        return ("fail", ".gitlab-ci.yml exists but does not run pnpm check-all + pnpm test:coverage")
    return (
        "manual",
        "no CI pipeline configured for useanymodels-web — regression testing relies on the "
        "agent-enforced CLAUDE.md rule (pnpm check-all + pnpm test:coverage after every task), "
        "not a git-enforced gate",
    )


def check_h3_llm_judge_criteria() -> tuple[str, str]:
    text = read(".claude/skills/uam-auto-implement/SKILL.md")
    ok = (
        "Verdict: PASS|REJECT" in text
        and "Critical Rules" in text
        and "95% coverage" in text
    )
    return (
        "pass" if ok else "fail",
        "uam-auto-implement.md Step 3 defines explicit PASS/REJECT criteria (CLAUDE.md rules + real gate + 95% coverage threshold) across the dispatched domain reviewers",
    )


def check_h3_feedback_loop_to_spec() -> tuple[str, str]:
    text = read(".claude/skills/uam-auto-implement/SKILL.md")
    logs_escalation = "escalation_log.py --task" in text
    reads_escalation = "escalation_log.py --find" in text
    script_exists = exists("harness/agentops/escalation_log.py")
    ok = logs_escalation and reads_escalation and script_exists
    return (
        "pass" if ok else "fail",
        "Step 3 logs REJECT findings via escalation_log.py; Step 1 looks up prior escalations "
        "by task keywords before investigating — closes REJECT findings back into future planning",
    )


def check_h4_sandbox_policy_live() -> tuple[str, str]:
    dangerous_code = run_hook("git reset --hard HEAD~1")
    safe_code = run_hook("git status")
    blocks_dangerous = dangerous_code == 2
    allows_safe = safe_code == 0

    def denies(stdout: str) -> bool:
        try:
            decoded = json.loads(stdout) if stdout else {}
        except json.JSONDecodeError:
            return False
        return decoded.get("hookSpecificOutput", {}).get("permissionDecision") == "deny"

    env_code, env_stdout = run_env_hook("Read", {"file_path": ".env"})
    safe_read_code, safe_read_stdout = run_env_hook("Read", {"file_path": "CLAUDE.md"})
    blocks_env_read = env_code == 0 and denies(env_stdout)
    allows_safe_read = safe_read_code == 0 and not denies(safe_read_stdout)

    ok = blocks_dangerous and allows_safe and blocks_env_read and allows_safe_read
    return (
        "pass" if ok else "fail",
        f"live hook invocation: dangerous Bash command exit {dangerous_code} "
        f"({'blocked' if blocks_dangerous else 'NOT blocked'}), safe Bash command exit {safe_code} "
        f"({'allowed' if allows_safe else 'NOT allowed'}); Read('.env') via a file tool "
        f"({'blocked' if blocks_env_read else 'NOT blocked'}), Read('CLAUDE.md') via a file tool "
        f"({'allowed' if allows_safe_read else 'NOT allowed'}) — sandbox covers both the "
        "Bash-level guard-dangerous-cmd.js and the file-tool-level guard-env-read.js",
    )


def check_h4_secret_scanning() -> tuple[str, str]:
    ci_text = read(".gitlab-ci.yml")
    ci_gitleaks = "gitleaks" in ci_text
    pre_commit = exists(".gitleaks.toml") or "detect-secrets" in read("package.json")
    ok = ci_gitleaks or pre_commit
    if ci_gitleaks:
        return ("pass", "secret-scan CI job runs gitleaks on every MR/push to develop")
    if pre_commit:
        return ("pass", ".gitleaks.toml + pre-commit secret scanning present")
    return (
        "fail",
        "no secret-scanning tool wired anywhere for useanymodels-web — known gap, "
        "redact.js/redact.py only cover harness's own log writes",
    )


def check_h4_prompt_injection_scan() -> tuple[str, str]:
    text = read("harness/security/guard-prompt-injection.js")
    wired = "guard-prompt-injection.js" in read(".claude/settings.json")
    ok = "INJECTION_PATTERNS" in text and wired
    return (
        "pass" if ok else "fail",
        "guard-prompt-injection.js scans every user prompt for injection heuristics "
        "(wired as a UserPromptSubmit hook), logs matches — does not hard-block due to false-positive risk",
    )


def check_h4_jailbreak_detection() -> tuple[str, str]:
    text = read("harness/security/guard-prompt-injection.js")
    wired = "guard-prompt-injection.js" in read(".claude/settings.json")
    ok = "JAILBREAK_PATTERNS" in text and wired
    return (
        "pass" if ok else "fail",
        "guard-prompt-injection.js scans every user prompt for jailbreak heuristics "
        "(same UserPromptSubmit hook as the injection scan), logs matches",
    )


def check_h4_pii_data_leakage() -> tuple[str, str]:
    redact_modules_exist = exists("harness/security/redact.js") and exists(
        "harness/agentops/redact.py"
    )
    wired_js = "redact" in read("harness/security/guard-dangerous-cmd.js")
    wired_py = "redact" in read("harness/agentops/agentops_log.py")
    ok = redact_modules_exist and wired_js and wired_py
    return (
        "pass" if ok else "fail",
        "redact.js/redact.py mask API keys, JWTs, bearer tokens, emails before command "
        "previews (block-log/audit-log) or task text (gate-log) are ever written to disk",
    )


def check_h5_risk_registry_tiers() -> tuple[str, str]:
    text = read("harness/governance/risk-registry.md")
    ok = "## Tier 0" in text and "## Tier 1" in text and "## Tier 2" in text
    return ("pass" if ok else "fail", "risk-registry.md defines Tier 0/1/2 explicitly")


def check_h5_ticket_linked_commits() -> tuple[str, str]:
    main_ref = "origin/develop"
    try:
        subprocess.run(
            ["git", "rev-parse", "--verify", main_ref],
            capture_output=True,
            text=True,
            cwd=REPO_ROOT,
            timeout=10,
            check=True,
        )
        log_range = f"{main_ref}..HEAD"
    except (subprocess.TimeoutExpired, subprocess.CalledProcessError):
        log_range = "-10"

    def commit_subjects(git_range: str) -> list[str]:
        try:
            result = subprocess.run(
                ["git", "log", "--no-merges", git_range, "--format=%s"],
                capture_output=True,
                text=True,
                cwd=REPO_ROOT,
                timeout=10,
            )
            return result.stdout.strip().splitlines()
        except subprocess.TimeoutExpired:
            return []

    subjects = commit_subjects(log_range)
    if not subjects and log_range != "-10":
        subjects = commit_subjects("-10")
        scope = "last 10 commits (branch has none ahead of origin/develop)"
    else:
        scope = f"ahead of {main_ref}" if log_range != "-10" else "last 10 commits"
    compliant = [s for s in subjects if re.match(r"^\[UAM-\d+\]:", s)]
    ok = bool(subjects) and len(compliant) == len(subjects)
    return (
        "pass" if ok else "fail",
        f"{len(compliant)}/{len(subjects)} commits ticket-linked ({scope})",
    )


def check_h5_compliance_report() -> tuple[str, str]:
    ok = exists("harness/agentops/generate_dashboard.py")
    return (
        "pass" if ok else "fail",
        "dashboard generator doubles as a periodic compliance report",
    )


def check_h5_human_approval_flow() -> tuple[str, str]:
    bash_code, bash_stdout = run_hook_full("pnpm add lodash")
    bash_asks = bash_code == 0 and '"permissionDecision":"ask"' in bash_stdout

    edit_code, edit_stdout = run_edit_hook(
        "Edit", str(REPO_ROOT / ".claude" / "settings.json")
    )
    edit_asks = edit_code == 0 and '"permissionDecision":"ask"' in edit_stdout

    ok = bash_asks and edit_asks
    return (
        "pass" if ok else "fail",
        "live hook invocation: `pnpm add lodash` -> "
        f"{'ask' if bash_asks else 'NOT ask'}, Edit .claude/settings.json -> "
        f"{'ask' if edit_asks else 'NOT ask'} — guard-dangerous-cmd.js Tier 2 emits "
        "permissionDecision:\"ask\", forcing the CLI's native interactive approval instead of "
        "relying on the agent choosing to ask",
    )


def check_h5_policy_engine_self_check() -> tuple[str, str]:
    text = read(".claude/settings.json")
    try:
        data = json.loads(text) if text else {}
    except json.JSONDecodeError:
        data = {}
    has_hook = bool(data.get("hooks", {}).get("PreToolUse"))
    has_allowlist = len(data.get("permissions", {}).get("allow", [])) > 0
    ok = has_hook and has_allowlist
    return (
        "pass" if ok else "fail",
        "PreToolUse hook + settings.json permission allowlist gate every tool call before execution",
    )


def check_h6_cost_tracking_live() -> tuple[str, str]:
    sys.path.insert(0, str(AGENTOPS_DIR))
    try:
        from token_usage import get_token_stats

        stats = get_token_stats()
        ok = stats.get("days", 0) > 0
        return (
            "pass" if ok else "manual",
            f"{stats.get('days', 0)} days of real session token data found",
        )
    except Exception as error:
        return ("fail", f"token_usage.py failed to execute: {error}")


def check_h6_gate_log_readable() -> tuple[str, str]:
    path = AGENTOPS_DIR / "gate-log.jsonl"
    if not path.exists():
        return ("manual", "no gate-log.jsonl yet — no /uam-auto-implement run logged")
    try:
        lines = [line for line in path.read_text().splitlines() if line.strip()]
        for line in lines:
            json.loads(line)
        return ("pass", f"{len(lines)} gate-log records, all valid JSON")
    except json.JSONDecodeError as error:
        return ("fail", f"gate-log.jsonl has malformed records: {error}")


def check_h6_alerting() -> tuple[str, str]:
    sys.path.insert(0, str(AGENTOPS_DIR))
    try:
        from alerting import find_alerts

        alerts = find_alerts()
        return (
            "pass",
            f"alerting.py live-executed: {len(alerts)} active fail-streak alert(s) "
            "(fires at >=3 consecutive REJECTs per task, wired into agentops_log.py)",
        )
    except Exception as error:
        return ("fail", f"alerting.py failed to execute: {error}")


def check_h6_drift_detection() -> tuple[str, str]:
    sys.path.insert(0, str(AGENTOPS_DIR))
    try:
        from drift_detection import detect_drift

        result = detect_drift()
        return (
            "pass",
            f"drift_detection.py live-executed: drift_detected={result['drift_detected']}, "
            f"{len(result['signals'])} signal(s) checked (pass-rate trend + token-usage trend)",
        )
    except Exception as error:
        return ("fail", f"drift_detection.py failed to execute: {error}")


def check_h6_dashboard_throughput_latency() -> tuple[str, str]:
    text = read("harness/agentops/generate_dashboard.py")
    ok = "throughput" in text.lower() and "latency" in text.lower()
    return (
        "pass" if ok else "fail",
        "generate_dashboard.py computes runs/day throughput + avg cross-cycle retry latency "
        "from gate-log.jsonl and renders both in the gate-log section"
        if ok
        else "generate_dashboard.py has no throughput/latency metrics for the pipeline — "
        "known gap, only token cost + checklist shown",
    )


def check_h7_dag_steps() -> tuple[str, str]:
    text = read(".claude/skills/uam-auto-implement/SKILL.md")
    steps = re.findall(r"### Step \d", text)
    ok = len(steps) >= 3
    return (
        "pass" if ok else "fail",
        f"{len(steps)} explicit numbered steps found in uam-auto-implement.md",
    )


def check_h7_parallel_execution() -> tuple[str, str]:
    text = read(".claude/skills/uam-review/SKILL.md")
    ok = "parallel" in text.lower() and "Task" in text
    return (
        "pass" if ok else "fail",
        "uam-review.md Step 3b dispatches parallel Task subagents",
    )


def check_h7_retry_cap() -> tuple[str, str]:
    return check_h3_auto_retry_capped()


def check_h7_back_to_plan_retry_cycle() -> tuple[str, str]:
    text = read(".claude/skills/uam-auto-implement/SKILL.md")
    ok = "REJECT" in text and "go back to Step 2" in text
    return (
        "pass" if ok else "fail",
        "uam-auto-implement.md Step 4 routes REJECT back to Step 2 (retry cycle), not just a hard stop",
    )


def check_h7_fallback_model() -> tuple[str, str]:
    text = read(".claude/skills/uam-auto-implement/SKILL.md")
    fallback_count = text.count("**Fallback:**")
    ok = fallback_count >= 3 and "general-purpose" in text
    return (
        "pass" if ok else "fail",
        f"{fallback_count} explicit fallback-to-general-purpose-agent paths defined "
        "(investigator/implementer/reviewer each has one)",
    )


def check_h7_transaction_rollback() -> tuple[str, str]:
    text = read(".claude/skills/uam-auto-implement/SKILL.md")
    ok = "Transaction boundary / rollback" in text and "git checkout -- " in text
    return (
        "pass" if ok else "fail",
        "uam-auto-implement.md defines the working tree as the transaction boundary (never "
        "auto-commits mid-flow) and gives explicit rollback commands when retries exhaust",
    )


CHECKS = [
    (
        "H1",
        "Context tập trung, không cần agent tự scan lại",
        "static",
        check_h1_context_files,
    ),
    (
        "H1",
        "Agent nhận path từ context thay vì hardcode/đoán",
        "static",
        check_h1_context_pointer_table,
    ),
    (
        "H1",
        "Có cơ chế làm sạch context khi outdated/stale",
        "static",
        check_h1_stale_cleanup,
    ),
    (
        "H1",
        "Context được cập nhật sau mỗi step, không cần agent tự scan lại",
        "static",
        check_h1_context_handoff_no_rescan,
    ),
    (
        "H1",
        "Tech stack và domain knowledge chỉ đọc một lần, cache lại",
        "static",
        check_h1_domain_knowledge_cached_once,
    ),
    ("H2", "Tool call có schema mô tả rõ", "static", check_h2_tool_schema),
    (
        "H2",
        "Tool registry, không hardcode URL/credential",
        "static",
        check_h2_tool_registry,
    ),
    ("H2", "Có rate limit/retry policy layer", "live", check_h2_rate_limit_tool),
    (
        "H2",
        "Có idempotency key cho các tool thay đổi hệ thống",
        "static",
        check_h2_idempotency_key,
    ),
    (
        "H2",
        "Có audit log ghi lại mỗi tool call",
        "static",
        check_h2_audit_log_per_tool_call,
    ),
    (
        "H3",
        "Golden dataset / test suite trước khi implement",
        "static",
        check_h3_test_suite,
    ),
    (
        "H3",
        "Gate cứng dừng nếu verdict REJECTED",
        "static",
        check_h3_gate_stops_on_reject,
    ),
    (
        "H3",
        "Gate có auto-retry với fix agent, giới hạn cycle",
        "static",
        check_h3_auto_retry_capped,
    ),
    (
        "H3",
        "Regression test chạy trước khi deploy",
        "static",
        check_h3_regression_in_ci,
    ),
    (
        "H3",
        "Review dùng LLM-as-judge với tiêu chí rõ ràng",
        "static",
        check_h3_llm_judge_criteria,
    ),
    (
        "H3",
        "Feedback từ môi trường thật quay lại update spec/plan",
        "static",
        check_h3_feedback_loop_to_spec,
    ),
    (
        "H4",
        "Có sandbox/timeout cho tool execution để tránh agent chạy lệnh nguy hiểm",
        "live",
        check_h4_sandbox_policy_live,
    ),
    (
        "H4",
        "Credential không hardcode — secret scanning",
        "static",
        check_h4_secret_scanning,
    ),
    (
        "H4",
        "Có scan prompt injection trong user input",
        "static",
        check_h4_prompt_injection_scan,
    ),
    ("H4", "Có cơ chế jailbreak detection", "static", check_h4_jailbreak_detection),
    (
        "H4",
        "Có kiểm tra data leakage — PII/nhạy cảm không đi vào log",
        "static",
        check_h4_pii_data_leakage,
    ),
    (
        "H5",
        "Risk registry — danh sách action cấm/cần review",
        "static",
        check_h5_risk_registry_tiers,
    ),
    (
        "H5",
        "Audit log — mọi commit gắn ticket, truy vết được",
        "live",
        check_h5_ticket_linked_commits,
    ),
    ("H5", "Có báo cáo compliance định kỳ", "static", check_h5_compliance_report),
    (
        "H5",
        "Có luồng phê duyệt con người trước khi agent thực thi action rủi ro cao",
        "live",
        check_h5_human_approval_flow,
    ),
    (
        "H5",
        "Có policy engine — agent tự check quyền trước khi gọi tool",
        "static",
        check_h5_policy_engine_self_check,
    ),
    (
        "H6",
        "Đo cost per agent run (token, thời gian)",
        "live",
        check_h6_cost_tracking_live,
    ),
    (
        "H6",
        "Track tỷ lệ PASS/REJECT (error rate) per step",
        "live",
        check_h6_gate_log_readable,
    ),
    ("H6", "Có alerting khi một step fail quá N lần", "live", check_h6_alerting),
    ("H6", "Có drift detection theo thời gian", "live", check_h6_drift_detection),
    (
        "H6",
        "Dashboard theo dõi throughput và latency của toàn pipeline",
        "static",
        check_h6_dashboard_throughput_latency,
    ),
    (
        "H7",
        "Pipeline có DAG rõ ràng — step phụ thuộc step nào",
        "static",
        check_h7_dag_steps,
    ),
    (
        "H7",
        "Có parallel execution cho step độc lập",
        "static",
        check_h7_parallel_execution,
    ),
    (
        "H7",
        "Có giới hạn số lần retry để tránh infinite loop",
        "static",
        check_h7_retry_cap,
    ),
    (
        "H7",
        "Có BACK-TO-PLAN / retry cycle khi gate fail",
        "static",
        check_h7_back_to_plan_retry_cycle,
    ),
    (
        "H7",
        "Có fallback — nếu model A fail, thử model B",
        "static",
        check_h7_fallback_model,
    ),
    (
        "H7",
        "Có transaction boundary — rollback được",
        "static",
        check_h7_transaction_rollback,
    ),
]


def run_all_checks() -> list[dict]:
    results = []
    for harness_id, item, kind, check_fn in CHECKS:
        try:
            status, evidence = check_fn()
        except Exception as error:
            status, evidence = "fail", f"check raised an exception: {error}"
        results.append(
            {
                "harness": harness_id,
                "item": item,
                "kind": kind,
                "status": status,
                "evidence": evidence,
            }
        )
    return results


def main() -> bool:
    results = run_all_checks()
    output_path = AGENTOPS_DIR / "verify-results.json"
    output_path.write_text(json.dumps(results, indent=2))

    by_status = {"pass": 0, "fail": 0, "manual": 0}
    for result in results:
        by_status[result["status"]] += 1
        marker = {"pass": "[PASS]", "fail": "[FAIL]", "manual": "[MANUAL]"}[
            result["status"]
        ]
        print(f"{marker} {result['harness']} ({result['kind']}) — {result['item']}")
        print(f"       {result['evidence']}")

    print("=" * 60)
    print(
        f"Total: {len(results)} — pass {by_status['pass']}, "
        f"fail {by_status['fail']}, manual {by_status['manual']}"
    )
    print(f"[SUCCESS] Wrote {output_path}")
    return by_status["fail"] == 0


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
