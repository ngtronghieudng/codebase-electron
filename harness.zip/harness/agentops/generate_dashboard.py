#!/usr/bin/env python3
import html
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

AGENTOPS_DIR = Path(__file__).parent
SCORE_HISTORY_PATH = AGENTOPS_DIR / "casan-score-history.jsonl"
GATE_LOG_PATH = AGENTOPS_DIR / "gate-log.jsonl"
ESCALATIONS_PATH = AGENTOPS_DIR / "escalations.jsonl"
BLOCK_LOG_PATH = AGENTOPS_DIR.parent / "security" / "block-log.jsonl"
TOOL_CALL_AUDIT_PATH = AGENTOPS_DIR.parent / "security" / "tool-call-audit.jsonl"
PROMPT_INJECTION_LOG_PATH = (
    AGENTOPS_DIR.parent / "security" / "prompt-injection-log.jsonl"
)
RISK_REGISTRY_PATH = AGENTOPS_DIR.parent / "governance" / "risk-registry.md"
ASSESSMENT_DOC_PATH = AGENTOPS_DIR.parent / "casan-harness-assessment.md"
OUTPUT_PATH = AGENTOPS_DIR.parent / "casan-harness-dashboard.html"

sys.path.insert(0, str(AGENTOPS_DIR))
from agent_activity import (
    get_agent_dispatch_stats,
    get_context_doc_read_count,
)
from alerting import find_alerts
from drift_detection import detect_drift
from token_usage import (
    get_token_stats,
    load_latest_member_tokens,
    sync_member_token_log,
)
from verify_harness import run_all_checks

HARNESS_NAMES = {
    "H1": "Context",
    "H2": "Tool",
    "H3": "Evaluation",
    "H4": "Security",
    "H5": "Governance",
    "H6": "AgentOps",
    "H7": "Orchestration",
}

TICKET_RE = re.compile(r"^\[UAM-\d+\]:")

GAP_THRESHOLD = 30
HEALTHY_THRESHOLD = 70
LEVEL5_AVERAGE_THRESHOLD = 80


def parse_key_questions() -> dict[str, str]:
    if not ASSESSMENT_DOC_PATH.exists():
        return {}
    text = ASSESSMENT_DOC_PATH.read_text()
    questions = {}
    for hid in HARNESS_NAMES:
        section = re.search(
            rf"### {hid} —.*?\*\*Câu hỏi chốt:\*\* \*(.+?)\*\n", text, re.DOTALL
        )
        if section:
            questions[hid] = section.group(1).strip()
    return questions


def summarize_tool_call_audit(records: list[dict]) -> dict:
    allowed = sum(1 for r in records if r["verdict"] == "allowed")
    blocked = sum(1 for r in records if r["verdict"] == "blocked")
    return {"total": len(records), "allowed": allowed, "blocked": blocked}


def summarize_prompt_injection(records: list[dict]) -> dict:
    injection = sum(1 for r in records if r["category"] == "injection")
    jailbreak = sum(1 for r in records if r["category"] == "jailbreak")
    return {"total": len(records), "injection": injection, "jailbreak": jailbreak}


def parse_governance_tiers() -> dict:
    if not RISK_REGISTRY_PATH.exists():
        return {"tier0": 0, "tier1": 0, "tier2": 0}
    text = RISK_REGISTRY_PATH.read_text()

    def section(heading: str) -> str:
        match = re.search(rf"## {heading}.*?\n(.*?)(?=\n## |\Z)", text, re.DOTALL)
        return match.group(1) if match else ""

    tier0_rows = re.findall(r"^\| `/", section("Tier 0"), re.MULTILINE)
    tier1_rows = re.findall(r"^\| `", section("Tier 1"), re.MULTILINE)
    tier2_items = re.findall(r"^- ", section("Tier 2"), re.MULTILINE)
    return {
        "tier0": len(tier0_rows),
        "tier1": len(tier1_rows),
        "tier2": len(tier2_items),
    }


def compute_level_conditions(scores: dict[str, int]) -> dict:
    gap_harnesses = [h for h, s in scores.items() if s < GAP_THRESHOLD]
    unhealthy_harnesses = [h for h, s in scores.items() if s < HEALTHY_THRESHOLD]
    average = sum(scores.values()) / len(scores) if scores else 0.0
    average_ok = average > LEVEL5_AVERAGE_THRESHOLD
    all_healthy = not unhealthy_harnesses
    return {
        "average": round(average, 1),
        "average_ok": average_ok,
        "all_healthy": all_healthy,
        "unhealthy_harnesses": unhealthy_harnesses,
        "gap_harnesses": gap_harnesses,
        "level5_conditions_met": average_ok and all_healthy,
    }


def load_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    records = []
    with path.open() as handle:
        for line in handle:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records


MAIN_BRANCH_REF = "origin/develop"


def run_git(args: list[str]) -> str:
    result = subprocess.run(
        ["git", *args], capture_output=True, text=True, check=True
    )
    return result.stdout.strip()


def get_git_stats() -> dict:
    total_commits = int(run_git(["rev-list", "--count", "HEAD"]))
    branch = run_git(["branch", "--show-current"])
    last_commit_raw = run_git(["log", "-1", "--format=%H|%ci|%s"])
    last_sha, last_date, last_subject = last_commit_raw.split("|", 2)

    try:
        run_git(["rev-parse", "--verify", MAIN_BRANCH_REF])
        recent_raw = run_git(["log", f"{MAIN_BRANCH_REF}..HEAD", "--format=%H|%ci|%s"])
    except subprocess.CalledProcessError:
        recent_raw = run_git(["log", "-30", "--format=%H|%ci|%s"])
    recent_commits = []
    for line in recent_raw.splitlines():
        sha, date, subject = line.split("|", 2)
        recent_commits.append(
            {
                "sha": sha[:8],
                "date": date,
                "subject": subject,
                "ticket_compliant": bool(TICKET_RE.match(subject)),
            }
        )

    compliant_count = sum(1 for c in recent_commits if c["ticket_compliant"])
    compliance_pct = (
        100 * compliant_count / len(recent_commits) if recent_commits else 0.0
    )

    return {
        "total_commits": total_commits,
        "branch": branch,
        "last_sha": last_sha[:8],
        "last_date": last_date,
        "last_subject": last_subject,
        "recent_commits": recent_commits,
        "compliance_pct": compliance_pct,
        "compliant_count": compliant_count,
        "sample_size": len(recent_commits),
    }


def _normalize_member_key(name: str) -> str:
    return name.strip().casefold()


def get_per_member_stats(gate_records: list[dict]) -> list[dict]:
    display_names: dict[str, str] = {}

    def _register(name: str) -> str:
        key = _normalize_member_key(name)
        display_names.setdefault(key, name.strip())
        return key

    commits_by_author: dict[str, list[str]] = {}
    log_raw = run_git(["log", "--all", "--no-merges", "--format=%an|%s"])
    for line in log_raw.splitlines():
        if "|" not in line:
            continue
        author, subject = line.split("|", 1)
        commits_by_author.setdefault(_register(author), []).append(subject)

    gate_by_member: dict[str, list[dict]] = {}
    for record in gate_records:
        member = record.get("git_user") or "unknown"
        gate_by_member.setdefault(_register(member), []).append(record)

    tokens_by_member = {
        _register(member): record
        for member, record in load_latest_member_tokens().items()
    }

    members = set(commits_by_author) | set(gate_by_member) | set(tokens_by_member)
    rows = []
    for member in members:
        subjects = commits_by_author.get(member, [])
        compliant = sum(1 for s in subjects if TICKET_RE.match(s))
        ticket_pct = 100 * compliant / len(subjects) if subjects else 0.0

        gate_summary = summarize_gate_log(gate_by_member.get(member, []))
        token_record = tokens_by_member.get(member)

        rows.append(
            {
                "member": display_names.get(member, member),
                "commits": len(subjects),
                "ticket_pct": ticket_pct,
                "gate_runs": gate_summary["total"],
                "pass_rate": gate_summary["pass_rate"],
                "first_pass_count": gate_summary["first_pass_count"],
                "distinct_tasks": gate_summary["distinct_tasks"],
                "latest_coverage": gate_summary["latest_coverage"],
                "billed_estimate_tokens": token_record["billed_estimate_tokens"]
                if token_record
                else None,
                "days_active": token_record["days_active"] if token_record else 0,
            }
        )
    rows.sort(key=lambda r: r["commits"], reverse=True)
    return rows


def compute_throughput_and_latency(records: list[dict]) -> dict:
    if not records:
        return {"runs_per_day": 0.0, "avg_retry_latency_seconds": None, "span_days": 0}

    timestamps = [datetime.fromisoformat(r["timestamp"]) for r in records]
    span_days = max((max(timestamps) - min(timestamps)).days, 0) + 1
    runs_per_day = len(records) / span_days

    by_task: dict[str, list[dict]] = {}
    for record in records:
        by_task.setdefault(record["task"], []).append(record)

    deltas = []
    for task_records in by_task.values():
        ordered = sorted(task_records, key=lambda r: r["cycle"])
        for prev, curr in zip(ordered, ordered[1:]):
            prev_time = datetime.fromisoformat(prev["timestamp"])
            curr_time = datetime.fromisoformat(curr["timestamp"])
            deltas.append((curr_time - prev_time).total_seconds())

    avg_retry_latency_seconds = sum(deltas) / len(deltas) if deltas else None
    return {
        "runs_per_day": runs_per_day,
        "avg_retry_latency_seconds": avg_retry_latency_seconds,
        "span_days": span_days,
    }


def summarize_gate_log(records: list[dict]) -> dict:
    if not records:
        return {
            "total": 0,
            "pass_count": 0,
            "reject_count": 0,
            "pass_rate": 0.0,
            "first_pass_count": 0,
            "distinct_tasks": 0,
            "latest_coverage": None,
            "recent": [],
        }
    passes = [r for r in records if r["verdict"] == "PASS"]
    rejects = [r for r in records if r["verdict"] == "REJECT"]
    tasks: dict[str, list[int]] = {}
    for r in records:
        tasks.setdefault(r["task"], []).append(r["cycle"])
    first_pass_tasks = [
        task
        for task, cycles in tasks.items()
        if max(cycles) == 1
        and any(r["task"] == task and r["verdict"] == "PASS" for r in records)
    ]
    coverage_values = [
        r["coverage_pct"] for r in records if r.get("coverage_pct") is not None
    ]
    return {
        "total": len(records),
        "pass_count": len(passes),
        "reject_count": len(rejects),
        "pass_rate": 100 * len(passes) / len(records),
        "first_pass_count": len(first_pass_tasks),
        "distinct_tasks": len(tasks),
        "latest_coverage": coverage_values[-1] if coverage_values else None,
        "recent": records[-10:],
    }


def summarize_verify(results: list[dict]) -> dict:
    by_harness: dict[str, dict] = {}
    for hid in HARNESS_NAMES:
        by_harness[hid] = {"pass": 0, "fail": 0, "manual": 0, "checks": []}
    for result in results:
        hid = result["harness"]
        bucket = by_harness.setdefault(
            hid, {"pass": 0, "fail": 0, "manual": 0, "checks": []}
        )
        bucket[result["status"]] += 1
        bucket["checks"].append(result)
    totals = {"pass": 0, "fail": 0, "manual": 0}
    for result in results:
        totals[result["status"]] += 1
    return {"by_harness": by_harness, "totals": totals, "total": len(results)}


def format_tokens(value: float) -> str:
    if value >= 1_000_000_000:
        return f"{value / 1_000_000_000:.2f}B"
    if value >= 1_000_000:
        return f"{value / 1_000_000:.2f}M"
    if value >= 1_000:
        return f"{value / 1_000:.1f}K"
    return str(int(value))


def render_html(
    score_history: list[dict],
    gate_summary: dict,
    git_stats: dict,
    verify_summary: dict,
    token_stats: dict,
    block_log: list[dict],
    throughput_latency: dict,
    alerts: list[dict],
    drift: dict,
    key_questions: dict[str, str],
    level_conditions: dict,
    tool_call_audit: list[dict],
    prompt_injection_log: list[dict],
    governance_tiers: dict,
    escalations: list[dict],
    agent_dispatch_stats: dict,
    context_doc_reads: dict,
    member_stats: list[dict],
) -> str:
    latest = score_history[-1] if score_history else None
    generated_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    total_live_checks = sum(
        1
        for bucket in verify_summary["by_harness"].values()
        for check in bucket["checks"]
        if check["kind"] == "live"
    )

    action_needed_rows = ""
    for hid in ["H1", "H2", "H3", "H4", "H5", "H6", "H7"]:
        for check in verify_summary["by_harness"].get(hid, {}).get("checks", []):
            if check["status"] not in ("fail", "manual"):
                continue
            icon = "✗" if check["status"] == "fail" else "•"
            action_needed_rows += f"""
        <tr>
          <td class="{check["status"]}">{icon} {check["status"]}</td>
          <td>{hid}</td>
          <td>{html.escape(check["item"])}</td>
          <td class="note">{html.escape(check["evidence"])}</td>
        </tr>"""
    if not action_needed_rows:
        action_needed_rows = (
            f'<tr><td colspan="4" class="empty">Nothing — 0 fail, 0 manual across '
            f'all {verify_summary["total"]} checks</td></tr>'
        )

    trend_points = ""
    trend_svg_width = 640
    trend_svg_height = 160
    if len(score_history) >= 1:
        avgs = [r["average"] for r in score_history]
        lo, hi = min(avgs + [60]), max(avgs + [85])
        span = hi - lo or 1
        n = len(score_history)
        step = trend_svg_width / max(n - 1, 1)
        coords = []
        for i, rescan in enumerate(score_history):
            x = i * step if n > 1 else trend_svg_width / 2
            y = (
                trend_svg_height
                - ((rescan["average"] - lo) / span) * (trend_svg_height - 20)
                - 10
            )
            coords.append((x, y))
        polyline = " ".join(f"{x:.1f},{y:.1f}" for x, y in coords)
        trend_points = f'<polyline points="{polyline}" fill="none" stroke="#58a6ff" stroke-width="2.5"/>'
        for i, (x, y) in enumerate(coords):
            rescan = score_history[i]
            trend_points += (
                f'<circle cx="{x:.1f}" cy="{y:.1f}" r="4" fill="#58a6ff"/>'
                f'<title>Rescan {rescan["rescan"]} ({rescan["date"]}): {rescan["average"]}</title>'
            )

    rescan_rows = ""
    for rescan in reversed(score_history):
        rescan_rows += f"""
        <tr>
          <td>#{rescan["rescan"]}</td>
          <td>{rescan["date"]}</td>
          <td><strong>{rescan["average"]}</strong></td>
          <td>{rescan["level"]}</td>
          <td class="note">{html.escape(rescan["note"])}</td>
        </tr>"""

    gate_recent_rows = ""
    for record in reversed(gate_summary["recent"]):
        verdict_class = "pass" if record["verdict"] == "PASS" else "reject"
        gate_recent_rows += f"""
        <tr>
          <td>{record["timestamp"][:19]}</td>
          <td class="{verdict_class}">{record["verdict"]}</td>
          <td>{record["cycle"]}</td>
          <td>{html.escape(record["task"])}</td>
        </tr>"""
    if not gate_recent_rows:
        gate_recent_rows = (
            '<tr><td colspan="4" class="empty">No gate runs logged yet</td></tr>'
        )

    commit_rows = ""
    for commit in git_stats["recent_commits"][:15]:
        compliant_mark = "✓" if commit["ticket_compliant"] else "✗"
        compliant_class = "pass" if commit["ticket_compliant"] else "reject"
        commit_rows += f"""
        <tr>
          <td><code>{commit["sha"]}</code></td>
          <td>{commit["date"][:10]}</td>
          <td class="{compliant_class}">{compliant_mark}</td>
          <td class="note">{html.escape(commit["subject"])}</td>
        </tr>"""

    block_rows = ""
    for record in reversed(block_log[-10:]):
        block_rows += f"""
        <tr>
          <td>{record["timestamp"][:19]}</td>
          <td class="note">{html.escape(record["reason"])}</td>
          <td class="cmd"><code>{html.escape(record["command_preview"])}</code></td>
        </tr>"""
    if not block_rows:
        block_rows = '<tr><td colspan="3" class="empty">No Tier-1 blocks recorded yet — hook has not needed to fire</td></tr>'

    audit_summary = summarize_tool_call_audit(tool_call_audit)
    audit_rows = ""
    for record in reversed(tool_call_audit[-10:]):
        verdict_class = "pass" if record["verdict"] == "allowed" else "reject"
        audit_rows += f"""
        <tr>
          <td>{record["timestamp"][:19]}</td>
          <td class="{verdict_class}">{record["verdict"]}</td>
          <td class="cmd"><code>{html.escape(record["command_preview"])}</code></td>
        </tr>"""
    if not audit_rows:
        audit_rows = (
            '<tr><td colspan="3" class="empty">No tool calls audited yet</td></tr>'
        )

    injection_summary = summarize_prompt_injection(prompt_injection_log)
    injection_rows = ""
    for record in reversed(prompt_injection_log[-10:]):
        injection_rows += f"""
        <tr>
          <td>{record["timestamp"][:19]}</td>
          <td class="reject">{html.escape(record["category"])}</td>
          <td class="note">{html.escape(record["label"])}</td>
          <td class="note">{html.escape(record["prompt_preview"])}</td>
        </tr>"""
    if not injection_rows:
        injection_rows = '<tr><td colspan="4" class="empty">No injection/jailbreak heuristics matched yet</td></tr>'

    escalation_rows = ""
    for record in reversed(escalations[-10:]):
        escalation_rows += f"""
        <tr>
          <td>{record["timestamp"][:19]}</td>
          <td>{record["cycle"]}</td>
          <td class="note">{html.escape(record["task"])}</td>
          <td class="note">{html.escape(record["findings"])}</td>
        </tr>"""
    if not escalation_rows:
        escalation_rows = '<tr><td colspan="4" class="empty">No escalations yet — no REJECT has fed back into a future investigation</td></tr>'

    token_daily = token_stats.get("daily", [])[-14:]
    max_billed = max(
        (
            d["input_tokens"]
            + d["output_tokens"]
            + d["cache_creation_tokens"] * 1.25
            + d["cache_read_tokens"] * 0.1
            for d in token_daily
        ),
        default=1,
    )
    token_bars = ""
    for day in token_daily:
        billed = (
            day["input_tokens"]
            + day["output_tokens"]
            + day["cache_creation_tokens"] * 1.25
            + day["cache_read_tokens"] * 0.1
        )
        pct = 100 * billed / max_billed if max_billed else 0
        token_bars += f"""
        <div class="token-bar-row">
          <div class="token-bar-label">{day["date"]}</div>
          <div class="bar-track"><div class="bar-fill" style="width:{pct:.1f}%;background:#58a6ff"></div></div>
          <div class="token-bar-value">{format_tokens(billed)}</div>
        </div>"""

    rtk = token_stats.get("rtk")
    rtk_html = ""
    if rtk:
        rtk_html = f"""
        <div class="header-stats" style="margin-top:16px">
          <div class="stat-tile"><div class="label">rtk commands run</div><div class="value">{rtk.get("total_commands", 0)}</div></div>
          <div class="stat-tile"><div class="label">rtk avg savings</div><div class="value">{rtk.get("avg_savings_pct", 0):.0f}%</div></div>
          <div class="stat-tile"><div class="label">rtk tokens saved</div><div class="value">{format_tokens(rtk.get("total_saved", 0))}</div></div>
        </div>"""

    dispatch_rows = (
        "".join(
            f"<tr><td><code>{html.escape(name)}</code></td><td>{count}</td></tr>"
            for name, count in agent_dispatch_stats["by_subagent_type"].items()
        )
        or '<tr><td colspan="2" class="empty">No Agent dispatches found in session transcripts</td></tr>'
    )

    member_rows = (
        "".join(
            f"""<tr>
        <td>{html.escape(m["member"])}</td>
        <td>{m["commits"]}</td>
        <td>{m["ticket_pct"]:.0f}%</td>
        <td>{m["gate_runs"]}</td>
        <td>{f"{m['pass_rate']:.0f}%" if m["gate_runs"] else "—"}</td>
        <td>{f"{m['first_pass_count']}/{m['distinct_tasks']}" if m["distinct_tasks"] else "—"}</td>
        <td>{f"{m['latest_coverage']:.1f}%" if m["latest_coverage"] is not None else "—"}</td>
        <td>{format_tokens(m["billed_estimate_tokens"]) if m["billed_estimate_tokens"] is not None else "—"}</td>
        <td>{m["days_active"]}</td>
      </tr>"""
            for m in member_stats
        )
        or '<tr><td colspan="9" class="empty">No commits or gate runs found</td></tr>'
    )

    extra_sections: dict[str, str] = {
        "H1": f"""
          <div class="verify-summary">Context doc reads (all sessions, real transcripts): CLAUDE.md read {context_doc_reads["claude_md"]}x, docs/architecture/ read {context_doc_reads["docs_architecture"]}x — evidence agents consult the pointer docs instead of re-deriving structure.</div>""",
        "H2": f"""
          <details open><summary>Tool-call audit — {audit_summary["total"]} calls ({audit_summary["allowed"]} allowed, {audit_summary["blocked"]} blocked)</summary>
            <table><tr><th>Timestamp</th><th>Verdict</th><th>Command</th></tr>{audit_rows}</table>
          </details>""",
        "H3": f"""
          <details open><summary>Escalations — {len(escalations)} REJECT finding(s) logged</summary>
            <table><tr><th>Timestamp</th><th>Cycle</th><th>Task</th><th>Findings</th></tr>{escalation_rows}</table>
          </details>""",
        "H4": f"""
          <details open><summary>Injection/jailbreak log — {injection_summary["total"]} match(es) ({injection_summary["injection"]} injection, {injection_summary["jailbreak"]} jailbreak)</summary>
            <table><tr><th>Timestamp</th><th>Category</th><th>Pattern</th><th>Prompt preview (redacted)</th></tr>{injection_rows}</table>
          </details>
          <details open><summary>Policy blocks — {len(block_log)} Tier-1 blocks recorded</summary>
            <table><tr><th>Timestamp</th><th>Reason</th><th>Command</th></tr>{block_rows}</table>
          </details>""",
        "H5": f"""
          <div class="verify-summary">Governance tiers: {governance_tiers["tier0"]} Tier 0 (auto) · {governance_tiers["tier1"]} Tier 1 (hook-blocked) · {governance_tiers["tier2"]} Tier 2 (ask-first)</div>
          <details open><summary>Recent commits — {git_stats["compliant_count"]}/{git_stats["sample_size"]} ticket-compliant, ahead of <code>{MAIN_BRANCH_REF}</code></summary>
            <table><tr><th>SHA</th><th>Date</th><th>Ticket</th><th>Subject</th></tr>{commit_rows}</table>
          </details>""",
        "H6": f"""
          <details open><summary>Token usage — {token_stats.get("days", 0)} days, {format_tokens(token_stats.get("billed_estimate_tokens", 0))} tokens billed-estimate</summary>
            {token_bars or '<div class="empty">No session data found under ~/.claude/projects/</div>'}
            {rtk_html}
          </details>
          <details open><summary>Gate log — {gate_summary["total"]} runs, {throughput_latency["runs_per_day"]:.2f}/day, avg retry latency {f"{throughput_latency['avg_retry_latency_seconds']:.0f}s" if throughput_latency["avg_retry_latency_seconds"] is not None else "n/a"}</summary>
            <table><tr><th>Timestamp</th><th>Verdict</th><th>Cycle</th><th>Task</th></tr>{gate_recent_rows}</table>
          </details>
          <details open><summary>Alerting &amp; drift — {len(alerts)} active alert(s)</summary>
            <table><tr><th>Signal</th><th>Status</th><th>Detail</th></tr>
              {"".join(f'<tr><td>Fail-streak: {html.escape(a["task"])}</td><td class="reject">ALERT</td><td class="note">{a["consecutive_rejects"]} consecutive REJECTs</td></tr>' for a in alerts) or '<tr><td colspan="3" class="empty">No fail-streak alerts</td></tr>'}
              {"".join(f'<tr><td>{html.escape(s["signal"])}</td><td class="{"reject" if s["drift"] else "pass"}">{"DRIFT" if s["drift"] else "OK"}</td><td class="note">{html.escape(s["reason"])}</td></tr>' for s in drift["signals"])}
            </table>
          </details>""",
        "H7": f"""
          <details open><summary>Agent dispatch history — {agent_dispatch_stats["total"]} Agent calls across all sessions (real transcripts, not just this session)</summary>
            <table><tr><th>Subagent type</th><th>Dispatch count</th></tr>{dispatch_rows}</table>
          </details>""",
    }

    harness_rows = ""
    for hid in ["H1", "H2", "H3", "H4", "H5", "H6", "H7"]:
        score = latest["scores"].get(hid) if latest else None
        pct = score if score is not None else 0
        if score is None:
            color = "#8b949e"
        elif score >= 80:
            color = "#3fb950"
        elif score >= 70:
            color = "#d29922"
        else:
            color = "#f85149"
        score_label = str(score) if score is not None else "—"
        verify = verify_summary["by_harness"].get(
            hid, {"pass": 0, "fail": 0, "manual": 0}
        )
        checks = verify.get("checks", [])
        live_count = sum(1 for c in checks if c["kind"] == "live")
        static_count = sum(1 for c in checks if c["kind"] == "static")
        checks_html = ""
        for check in checks:
            icon = {"pass": "✓", "fail": "✗", "manual": "•"}[check["status"]]
            cls = check["status"]
            checks_html += (
                f'<div class="check-row {cls}">'
                f'<span class="check-icon">{icon}</span>'
                f'<span class="check-item">{html.escape(check["item"])}</span>'
                f'<span class="check-kind">{html.escape(check["kind"])}</span>'
                f"</div>"
                f'<div class="check-evidence">{html.escape(check["evidence"])}</div>'
            )
        question = key_questions.get(hid, "")
        question_html = (
            f'<div class="key-question">"{html.escape(question)}"</div>'
            if question
            else ""
        )
        harness_rows += f"""
        <div class="harness-card">
          <div class="harness-head">
            <div class="harness-title">{hid} · {HARNESS_NAMES[hid]}</div>
            <div class="harness-score" style="color:{color}">{score_label}</div>
          </div>
          <div class="bar-track"><div class="bar-fill" style="width:{pct:.1f}%;background:{color}"></div></div>
          <div class="verify-summary">Live verify: {verify['pass']} pass · {verify['fail']} fail · {verify['manual']} manual ({live_count} live-executed · {static_count} static)</div>
          {question_html}
          <details open><summary>Checklist detail</summary>{checks_html}</details>
          {extra_sections.get(hid, "")}
        </div>"""

    return f"""<title>CASAN Harness Dashboard — useanymodels-web</title>
<style>
  :root {{
    color-scheme: dark;
    --bg: #0d1117;
    --panel: #161b22;
    --border: #30363d;
    --text: #c9d1d9;
    --muted: #8b949e;
    --accent: #58a6ff;
    --pass: #3fb950;
    --reject: #f85149;
    --manual: #d29922;
  }}
  * {{ box-sizing: border-box; }}
  body {{
    margin: 0;
    padding: 32px;
    background: var(--bg);
    color: var(--text);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    max-width: 1100px;
    margin-inline: auto;
  }}
  h1 {{ font-size: 22px; margin-bottom: 4px; }}
  .subtitle {{ color: var(--muted); font-size: 13px; margin-bottom: 28px; }}
  .header-stats {{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 12px;
    margin-bottom: 32px;
  }}
  .stat-tile {{
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 14px 16px;
  }}
  .stat-tile .label {{ color: var(--muted); font-size: 11px; text-transform: uppercase; letter-spacing: 0.04em; }}
  .stat-tile .value {{ font-size: 24px; font-weight: 600; margin-top: 4px; }}
  section {{
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 20px 24px;
    margin-bottom: 24px;
    overflow-x: auto;
  }}
  section h2 {{ font-size: 15px; margin: 0 0 16px; color: var(--text); }}
  section p.hint {{ color: var(--muted); font-size: 12px; margin: -10px 0 16px; }}
  .bar-track {{ flex: 1; background: #21262d; border-radius: 4px; height: 14px; overflow: hidden; }}
  .bar-fill {{ height: 100%; border-radius: 4px; }}
  .token-bar-row {{ display: flex; align-items: center; gap: 12px; margin-bottom: 8px; }}
  .token-bar-label {{ width: 90px; font-size: 12px; color: var(--muted); flex-shrink: 0; }}
  .token-bar-value {{ width: 60px; text-align: right; font-size: 12px; font-variant-numeric: tabular-nums; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 13px; }}
  th {{ text-align: left; color: var(--muted); font-weight: 500; font-size: 11px; text-transform: uppercase; letter-spacing: 0.03em; padding: 6px 10px; border-bottom: 1px solid var(--border); }}
  td {{ padding: 7px 10px; border-bottom: 1px solid #21262d; white-space: nowrap; }}
  td.note {{ white-space: normal; color: var(--text); }}
  td.cmd {{ white-space: normal; word-break: break-all; }}
  td.empty {{ color: var(--muted); text-align: center; }}
  .pass {{ color: var(--pass); font-weight: 600; }}
  .reject {{ color: var(--reject); font-weight: 600; }}
  .manual {{ color: var(--manual); font-weight: 600; }}
  code {{ background: #21262d; padding: 1px 6px; border-radius: 4px; font-size: 12px; }}
  svg {{ display: block; margin: 0 auto; }}
  .footer {{ color: var(--muted); font-size: 11px; text-align: center; margin-top: 8px; }}

  .harness-card {{
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 14px 16px;
    margin-bottom: 12px;
  }}
  .harness-head {{ display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 8px; }}
  .harness-title {{ font-size: 14px; font-weight: 600; }}
  .harness-score {{ font-size: 20px; font-weight: 700; }}
  .verify-summary {{ font-size: 12px; color: var(--muted); margin: 8px 0; }}
  details {{ margin-top: 16px; }}
  details summary {{ cursor: pointer; font-size: 12px; color: var(--accent); margin-top: 4px; }}
  .check-row {{ display: flex; gap: 8px; align-items: baseline; margin-top: 8px; font-size: 12px; }}
  .check-icon {{ width: 14px; flex-shrink: 0; }}
  .check-row.pass .check-icon {{ color: var(--pass); }}
  .check-row.fail .check-icon {{ color: var(--reject); }}
  .check-row.manual .check-icon {{ color: var(--manual); }}
  .check-item {{ flex: 1; }}
  .check-kind {{ color: var(--muted); font-size: 10px; text-transform: uppercase; }}
  .check-evidence {{ font-size: 11px; color: var(--muted); margin-left: 22px; margin-bottom: 4px; }}
  .key-question {{ font-size: 12px; font-style: italic; color: var(--accent); margin: 6px 0; }}
  .level-condition {{ display: flex; align-items: baseline; gap: 8px; margin-top: 8px; font-size: 13px; }}
  .level-condition .icon {{ width: 16px; }}
</style>
<body>
  <h1>CASAN Harness Dashboard</h1>
  <div class="subtitle">useanymodels-web — Claude Code dev-workflow harness. Scores from rescans (judgment); checklist rows from live/static verify runs (mechanical) — see harness/casan-harness-assessment.md for full methodology.</div>

  <div class="header-stats">
    <div class="stat-tile"><div class="label">CASAN Average</div><div class="value">{latest["average"] if latest else "n/a"}</div></div>
    <div class="stat-tile"><div class="label">Level</div><div class="value" style="font-size:16px">{latest["level"] if latest else "n/a"}</div></div>
    <div class="stat-tile"><div class="label">Live verify pass rate</div><div class="value">{100 * verify_summary["totals"]["pass"] / verify_summary["total"]:.0f}%</div></div>
    <div class="stat-tile"><div class="label">Gate PASS rate</div><div class="value">{gate_summary["pass_rate"]:.0f}%</div></div>
    <div class="stat-tile"><div class="label">Commit compliance</div><div class="value">{git_stats["compliance_pct"]:.0f}%</div></div>
    <div class="stat-tile"><div class="label">Live-executed checks</div><div class="value">{total_live_checks}/{verify_summary["total"]}</div></div>
  </div>

  <section>
    <h2>Action needed — fail + manual checks across all 7 harnesses</h2>
    <p class="hint">Flattened from the scorecard below so you don't have to open all 7 cards to see what needs attention.</p>
    <table>
      <tr><th>Status</th><th>Harness</th><th>Item</th><th>Evidence</th></tr>
      {action_needed_rows}
    </table>
  </section>

  <section>
    <h2>Per-member effectiveness &amp; token usage</h2>
    <p class="hint">Commits: <code>git log --all --no-merges</code>, every author in repo history. Gate runs: gate-log.jsonl tagged with git_user at write time — shared via git, so every member's uam-reviewer run shows up here once committed. Tokens: member-token-log.jsonl, synced from each member's local ~/.claude/projects session log the moment they run this script — a member's token/days numbers only appear after they've generated the dashboard at least once on their own machine.</p>
    <table>
      <tr><th>Member</th><th>Commits</th><th>Ticket %</th><th>Gate runs</th><th>Pass rate</th><th>First-pass</th><th>Latest coverage</th><th>Tokens (billed-est)</th><th>Days active</th></tr>
      {member_rows}
    </table>
  </section>

  <section>
    <h2>Harness scorecard + live verification (#{latest["rescan"] if latest else "?"}, {latest["date"] if latest else ""})</h2>
    <p class="hint">Each row's checklist is executed live against this repo every time this dashboard regenerates — not a static claim.</p>
    {harness_rows or '<div class="empty">No score history yet</div>'}
  </section>

  <section>
    <h2>CASAN Level conditions — computed live from current scores</h2>
    <p class="hint">Level 5 requires all three below. Mechanically derived from the score table above, not a self-reported claim.</p>
    <div class="level-condition"><span class="icon {"pass" if level_conditions["average_ok"] else "reject"}">{"✓" if level_conditions["average_ok"] else "✗"}</span> Average &gt; 80: <strong>{level_conditions["average"]}</strong></div>
    <div class="level-condition"><span class="icon {"pass" if level_conditions["all_healthy"] else "reject"}">{"✓" if level_conditions["all_healthy"] else "✗"}</span> All harness &gt; 70{f': below threshold — {", ".join(level_conditions["unhealthy_harnesses"])}' if level_conditions["unhealthy_harnesses"] else ""}</div>
    <div class="level-condition"><span class="icon {"pass" if not level_conditions["gap_harnesses"] else "reject"}">{"✓" if not level_conditions["gap_harnesses"] else "✗"}</span> No Critical GAP (score &lt; 30){f': {", ".join(level_conditions["gap_harnesses"])}' if level_conditions["gap_harnesses"] else ""}</div>
    <p class="hint" style="margin-top:12px">Caveats and roadmap are judgment calls, not mechanically derivable — see <code>harness/casan-harness-assessment.md</code> §5 for the current caveat list and priority roadmap.</p>
  </section>

  <section>
    <h2>CASAN average over time</h2>
    <svg width="{trend_svg_width}" height="{trend_svg_height}" viewBox="0 0 {trend_svg_width} {trend_svg_height}">
      {trend_points}
    </svg>
  </section>

  <section>
    <h2>Rescan history</h2>
    <table>
      <tr><th>#</th><th>Date</th><th>Average</th><th>Level</th><th>What changed</th></tr>
      {rescan_rows}
    </table>
  </section>

  <div class="footer">Generated {generated_at} by harness/agentops/generate_dashboard.py — run manually after pnpm check-all + pnpm test:coverage per CLAUDE.md</div>
</body>
"""


def main() -> bool:
    sync_member_token_log()
    score_history = load_jsonl(SCORE_HISTORY_PATH)
    gate_records = load_jsonl(GATE_LOG_PATH)
    gate_summary = summarize_gate_log(gate_records)
    git_stats = get_git_stats()
    member_stats = get_per_member_stats(gate_records)
    verify_results = run_all_checks()
    verify_summary = summarize_verify(verify_results)
    token_stats = get_token_stats()
    block_log = load_jsonl(BLOCK_LOG_PATH)
    throughput_latency = compute_throughput_and_latency(gate_records)
    alerts = find_alerts()
    drift = detect_drift()
    key_questions = parse_key_questions()
    latest_scores = score_history[-1]["scores"] if score_history else {}
    level_conditions = compute_level_conditions(latest_scores)
    tool_call_audit = load_jsonl(TOOL_CALL_AUDIT_PATH)
    prompt_injection_log = load_jsonl(PROMPT_INJECTION_LOG_PATH)
    governance_tiers = parse_governance_tiers()
    escalations = load_jsonl(ESCALATIONS_PATH)
    agent_dispatch_stats = get_agent_dispatch_stats()
    context_doc_reads = get_context_doc_read_count()

    html = render_html(
        score_history,
        gate_summary,
        git_stats,
        verify_summary,
        token_stats,
        block_log,
        throughput_latency,
        alerts,
        drift,
        key_questions,
        level_conditions,
        tool_call_audit,
        prompt_injection_log,
        governance_tiers,
        escalations,
        agent_dispatch_stats,
        context_doc_reads,
        member_stats,
    )
    OUTPUT_PATH.write_text(html)
    print(f"[SUCCESS] Wrote {OUTPUT_PATH}")
    return True


if __name__ == "__main__":
    success = main()
    raise SystemExit(0 if success else 1)
