#!/usr/bin/env python3
import glob
import json
import subprocess
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

AGENTOPS_DIR = Path(__file__).parent
MEMBER_TOKEN_LOG_PATH = AGENTOPS_DIR / "member-token-log.jsonl"


def session_dir() -> Path:
    slug = str(Path.cwd()).replace("/", "-")
    return Path.home() / ".claude" / "projects" / slug


def load_daily_usage() -> dict[str, dict]:
    directory = session_dir()
    if not directory.exists():
        return {}

    daily: dict[str, dict] = defaultdict(
        lambda: {
            "messages": 0,
            "input_tokens": 0,
            "output_tokens": 0,
            "cache_read_tokens": 0,
            "cache_creation_tokens": 0,
        }
    )

    for file_path in glob.glob(str(directory / "*.jsonl")):
        try:
            with open(file_path, encoding="utf-8") as handle:
                for line in handle:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        record = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if record.get("type") != "assistant":
                        continue
                    message = record.get("message")
                    if not isinstance(message, dict):
                        continue
                    usage = message.get("usage")
                    timestamp = record.get("timestamp")
                    if not usage or not timestamp:
                        continue
                    day = timestamp[:10]
                    bucket = daily[day]
                    bucket["messages"] += 1
                    bucket["input_tokens"] += usage.get("input_tokens", 0)
                    bucket["output_tokens"] += usage.get("output_tokens", 0)
                    bucket["cache_read_tokens"] += usage.get(
                        "cache_read_input_tokens", 0
                    )
                    bucket["cache_creation_tokens"] += usage.get(
                        "cache_creation_input_tokens", 0
                    )
        except OSError as error:
            print(
                f"[WARN] Skipping unreadable session file {file_path}: {error}",
                file=sys.stderr,
            )
            continue

    return dict(sorted(daily.items()))


def summarize(daily: dict[str, dict]) -> dict:
    if not daily:
        return {
            "days": 0,
            "messages": 0,
            "input_tokens": 0,
            "output_tokens": 0,
            "cache_read_tokens": 0,
            "cache_creation_tokens": 0,
            "billed_estimate_tokens": 0,
            "daily": [],
        }
    totals = {
        "messages": 0,
        "input_tokens": 0,
        "output_tokens": 0,
        "cache_read_tokens": 0,
        "cache_creation_tokens": 0,
    }
    for bucket in daily.values():
        for key in totals:
            totals[key] += bucket[key]
    billed_estimate = (
        totals["input_tokens"]
        + totals["output_tokens"]
        + totals["cache_creation_tokens"] * 1.25
        + totals["cache_read_tokens"] * 0.1
    )
    return {
        "days": len(daily),
        "billed_estimate_tokens": round(billed_estimate),
        "daily": [{"date": date, **bucket} for date, bucket in daily.items()],
        **totals,
    }


def get_rtk_stats() -> dict | None:
    try:
        result = subprocess.run(
            ["rtk", "gain", "-p", "--format", "json"],
            capture_output=True,
            text=True,
            check=True,
            timeout=10,
        )
        return json.loads(result.stdout).get("summary")
    except (
        FileNotFoundError,
        subprocess.CalledProcessError,
        subprocess.TimeoutExpired,
        json.JSONDecodeError,
    ):
        return None


def get_token_stats() -> dict:
    daily = load_daily_usage()
    summary = summarize(daily)
    summary["rtk"] = get_rtk_stats()
    return summary


def git_user() -> str:
    try:
        result = subprocess.run(
            ["git", "config", "user.name"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        name = result.stdout.strip()
        return name if name else "unknown"
    except (subprocess.TimeoutExpired, OSError):
        return "unknown"


def sync_member_token_log() -> dict:
    stats = get_token_stats()
    record = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "git_user": git_user(),
        "days_active": stats["days"],
        "billed_estimate_tokens": stats["billed_estimate_tokens"],
    }
    MEMBER_TOKEN_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with MEMBER_TOKEN_LOG_PATH.open("a") as log_file:
        log_file.write(json.dumps(record) + "\n")
    return record


def load_latest_member_tokens() -> dict[str, dict]:
    if not MEMBER_TOKEN_LOG_PATH.exists():
        return {}
    latest: dict[str, dict] = {}
    for line in MEMBER_TOKEN_LOG_PATH.read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        member = record.get("git_user", "unknown")
        existing = latest.get(member)
        if existing is None or record["timestamp"] > existing["timestamp"]:
            latest[member] = record
    return latest


if __name__ == "__main__":
    print(json.dumps(get_token_stats(), indent=2))
