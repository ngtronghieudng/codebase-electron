# Harness

Enforcement + observability layer for this repo, evaluated against the CASAN framework (full H1-H7 rubric and this repo's real scores: `harness/casan-harness-assessment.md`).

Two layers run independently:

1. **Always-on hooks** (H4 Security) — every tool call and every prompt, wired in `.claude/settings.json`, no opt-in.
2. **Orchestrated pipeline** (H6 AgentOps) — `/uam-auto-implement` → `/uam-review`, a gate-verified investigate/edit/verify loop that feeds layer-1's logs into a dashboard.

## 1. Always-on hooks

`PreToolUse` → `security/guard-dangerous-cmd.js` on every tool call: **Tier 1** dangerous commands (force-push, `rm -rf`, `.env` writes, ...) are physically blocked; **Tier 2** risky-but-legitimate ones (`pnpm add/remove`, `npx`, `claude mcp add/remove`, `sudo`, ...) force the CLI's approval prompt; everything else is allowed. Every decision is logged to `security/*.jsonl`. `governance/risk-registry.md` is the human-readable mirror of the same table — the hook is the source of truth.

`UserPromptSubmit` → `security/guard-prompt-injection.js` scans each prompt for injection/jailbreak heuristics. Never blocks, just logs and nudges Claude to stay skeptical of embedded instructions.

## 2. Orchestrated pipeline

`/uam-auto-implement` runs investigate → edit → verify per cycle. The verify step (`uam-reviewer`) runs the real gate (`pnpm check-all && pnpm test:coverage`, ≥95% coverage) and verdicts PASS/REJECT — REJECT loops back, PASS logs the result (`agentops/gate-log.jsonl`) and regenerates the dashboard. This closes the CASAN H6 gap: the verdict is gate-verified, not self-reported.

## 3. Dashboard + self-check

`agentops/generate_dashboard.py` joins `git log`, `gate-log.jsonl`, and per-member token usage into `casan-harness-dashboard.html`. `agentops/verify_harness.py` runs a standalone H1-H7 checklist against the live repo (including actually invoking the security hook) and writes `agentops/verify-results.json`.

## Layout

| Path                           | Harness       | Role                                                                            |
| ------------------------------ | ------------- | ------------------------------------------------------------------------------- |
| `security/`                    | H4 Security   | The two hooks above, plus their `.jsonl` logs                                   |
| `governance/`                  | H5 Governance | `risk-registry.md` — human-readable Tier 0/1/2 table                            |
| `agentops/`                    | H6 AgentOps   | Gate log, token log, dashboard generator, self-verification script              |
| `context/`                     | H1 Context    | `memory-hygiene.md` — Serena/Claude local memory pruning guidance               |
| `casan-harness-assessment.md`  | —             | Full CASAN H1-H7 maturity rubric + this repo's real scores                      |
| `casan-harness-dashboard.html` | —             | Generated scorecard — rebuild: `python3 harness/agentops/generate_dashboard.py` |
